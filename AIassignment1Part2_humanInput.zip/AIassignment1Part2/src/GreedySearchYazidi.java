
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Vector;



public class GreedySearchYazidi extends Yazidi {
	private Graph _powerGraph;
	public GreedySearchYazidi(Vertex _location, Vertex _goal, int _foodCarried, int id,Graph g) {
		super(_location, _goal, _foodCarried, id);
		_powerGraph = Graph.makePowerGraph(g);

		for(Vertex v: _powerGraph.get_vertices())
			if(v.get_num()==_goal.get_num()){
				Dijkstra.computePaths(v,_powerGraph,false);
				break;
			}
		_path = ConvertToReal(g,GeneralSearch());
		for(Vertex v: _path)
			System.out.print(v.getName()+", ");
	}
	
	private List<Vertex> ConvertToReal(Graph g, List<Vertex> list) {
		Vector<Vertex> realList = new Vector<Vertex>();
		for(Vertex v: list)
			for(Vertex realV: g.get_vertices())
				if(v.get_num()==realV.get_num()){
					realList.add(realV);
					break;
				}
		return realList;
	}

	@Override
	public Action getAction(Graph g) {

		if(noRouteOrAtGoal()||notEnoughFood()){
				System.out.println(this +" Chose NoOp");
				return new Action(ActionType.NoOp, null);
			}
		System.out.println(this +" Chose to move to "+_path.get(0).getName());
		return new Action(ActionType.Traverse, _path.remove(0));
	}
	
	public double heuristic(Node v){
		//System.out.println("H("+v.get_state().getName()+")="+v.get_state().minDistance);
		return v.get_state().minDistance;
	}

	public List<Vertex> GeneralSearch() {
		PriorityQueue<Node> nodes = makeEmptyQueue();
		for(Vertex v: _powerGraph.get_vertices())
			if(v.get_num()==_location.get_num()){
				nodes.add(new Node(null, v,_foodCarried, 0));
				break;
			}
		
		Node node = null;
		while(true){
			if(nodes.isEmpty())
				return null;//Failure
			for(Node n: nodes)
				System.out.print(" || "+n.get_state().getName());
			System.out.println();
			node = nodes.remove();
			System.out.println();
			if(goalTest(node))
				return buildRoute(node);
			nodes.addAll(node.expand());
		}
	}
	
	private List<Vertex> buildRoute(Node node) {
		Vector<Vertex> route = new Vector<Vertex>();
		while(node != null){
			route.add(node.get_state());
			node = node.get_parent();
		}
		Collections.reverse(route);
		if(!route.isEmpty())
			route.remove(0);
		return route;
	}
	
	

	private boolean goalTest(Node node) {
		return heuristic(node)==0;
	}

	private PriorityQueue<Node> makeEmptyQueue() {
		PriorityQueue<Node> nodes = new PriorityQueue<Node>(new Comparator<Node>() {
			
			@Override
			public int compare(Node arg0, Node arg1) {
				// TODO Auto-generated method stub
				return (int) (heuristic(arg0) - heuristic(arg1));
			}
	});
		return nodes;
	}
}
