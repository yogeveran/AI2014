Instructions on how to create the world.

1. First Line MUST be of format:
#V n initialSupplies1 initialSupplies2 ... initialSuppliesn

Where n is an integer from 1 to 1000
This will create n of vertices from 1 to n including.
and initialSuppliesi is the amount of supplies in the vertex i

2. To add edges just add the line
#E A B weight


3. To add Agents just put:

#A type [start] [goal] [maxExpansions]

where type is:
1 - Human, 2 - Obama, 3 - greedy Yazidi, 4 - greedy ISIS, 5 - greedy Search Yazidi, 6 - A* Yazidi, 7 - RTA* Yazidi