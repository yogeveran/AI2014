
public enum ActionType {
 Traverse,NoOp,Aid,Bomb;
}
