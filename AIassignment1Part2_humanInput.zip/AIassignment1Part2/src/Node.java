import java.util.Collection;
import java.util.Vector;


public class Node {
	private Node _parent;
	private Vertex _state;
	private double _debth;
	private Vector<Node> _children;
	private double _currentSupplies;
	
	public Node(Node _parent, Vertex _state,double supplies, double _debth) {
		super();
		this._parent = _parent;
		this._state = _state;
		this._debth = _debth;
		this._children = new Vector<Node>();
		this._currentSupplies = supplies;
	}
	

	public Node get_parent() {
		return _parent;
	}

	public Vertex get_state() {
		return _state;
	}

	public double get_debth() {
		return _debth;
	}

	public Collection<? extends Node> expand() {
		System.out.println("Expanding "+this.get_state().getName());
		Vector<Node> nodes = new Vector<Node>();
		for(Edge e: _state.view_neighbors()){
			System.out.println("->" +e.get_target().getName());
			double newDebth =  (Math.sqrt(e.get_weight()) > _currentSupplies ? Double.POSITIVE_INFINITY : (_debth+_currentSupplies*Math.sqrt(e.get_weight())));
			double nextSupplies = _currentSupplies-Math.sqrt(e.get_weight()) + e.get_target().view_supplies();
			Node n = new Node(this, e.get_target(), nextSupplies, newDebth);
			System.out.println("Create Node: vertex-"+e.get_target().get_num()+" supplies:"+nextSupplies+" newDepth:"+newDebth);
			if(newDebth!=Double.POSITIVE_INFINITY){
				nodes.add(n);
				_children.add(n);
			}
		}
		//Add noOp Node
		Node n1 = new Node(this, _state, _currentSupplies-1, (( _currentSupplies>0) ? (_currentSupplies - 1) : Double.POSITIVE_INFINITY));
		if(n1._debth!=Double.POSITIVE_INFINITY){
			nodes.add(n1);
			_children.add(n1);}
		for(Node n: nodes)
			System.out.print(" |--| "+n.get_state().getName());
		System.out.println();
		return nodes;
	}


	public void removeChild(Node child) {
		_children.remove(child);
		
	}


	public void addChild(Node child) {
		_children.add(child);
		
	}


	public void set_parent(Node node) {
		this._parent = node;
	}


	public Vector<Node> get_children() {
		// TODO Auto-generated method stub
		return _children;
	}


	public void add_depth(double d) {
		_debth+=d;
		
	}

	

}
