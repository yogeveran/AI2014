import java.util.List;


public class Yazidi implements Agent {

	private int _id;

	public Yazidi(Vertex _location, Vertex _goal, int _foodCarried,int id) {
		super();
		this._location = _location;
		this._goal = _goal;
		this._foodCarried = _foodCarried;
		this._path = null;
		this._id = id;
	}
	private Vertex _location;
	private Vertex _goal;
	private int _foodCarried;
	private List<Vertex> _path;
	private double _cost;
	
	@Override
	public Action getAction(Graph g) {
		if(this._path == null){
			Dijkstra.computePaths(this._location,g,false);
			this._path = Dijkstra.getShortestPathTo(_goal);
			_path.remove(0);
			}
		if(noRouteOrAtGoal()||notEnoughFood())
			return new Action(ActionType.NoOp, null);
		return new Action(ActionType.Traverse, _path.remove(0));
	}

	public Vertex get_location() {
		return _location;
	}

	public void set_location(Vertex _location) {
		this._location = _location;
	}

	public int get_foodCarried() {
		return _foodCarried;
	}

	public void set_foodCarried(int _foodCarried) {
		this._foodCarried = _foodCarried;
	}

	public Vertex get_goal() {
		return _goal;
	}

	private boolean notEnoughFood() {
		return findEdge(_path.get(0)).get_weight()>this._foodCarried;
	}

	public Edge findEdge(Vertex target) {
		for(Edge e: this._location.view_neighbors()){
			if(target == e.get_target()){
				return e;
			}		}
		return null;
	}

	private boolean noRouteOrAtGoal() {
		return _path.size()==0;
	}

	@Override
	public void addCost(double cost) {
		this._cost+=cost;
		
	}

	@Override
	public double getCost() {
		return this._cost;
	}

	public void setCost(double cost) {
		_cost = cost;
		
	}

	@Override
	public void printAgent() {
		String status = (_location==_goal) ? "win" : ((_cost == Double.POSITIVE_INFINITY) ? "dead" : "alive");
		System.out.println("Y"+_id+":score("+_cost+"):food("+_foodCarried+"):loc("+_location+"):status(" +status+ ")" );
	}

	public void addFood(int i) {
		_foodCarried+=i;
	}

}
